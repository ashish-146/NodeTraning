const TodoDao = require("./Dao/TodoDao");
const todoDao = new TodoDao();
const express = require("express");
// const path = require("path");
const app = express();
const port=4000;



const operation = async () => {
    let savedTodo = await todoDao.saveEntity({
        title: "Read a book of JS",
        completed: 0
    });
    console.log("Saved todo --> ", savedTodo)

    savedTodo.completed = 1;
    let isUpdated = await todoDao.updateEntity(savedTodo);
    console.log("Is it updated --> ", isUpdated);

    let todoList = await todoDao.readEntities();
    console.log("List of todo --> ", todoList);

    let isDeleted = await todoDao.deleteEntity(savedTodo.id);
    console.log("Is it deleted --> ", isDeleted)
}

// operation();

// app.get("/", (_req, res) => {
// 	res.sendFile(path.join(path.resolve("dist"), "index.html"));
// });

app.get("/getAll",  async (_req, res) => {
	// dbo.collection("employees")
		// .find()
		// .toArray((err, result) => {
        // 	if (err) throw err;
        let todoList = await todoDao.readEntities();
        console.log("List of todo --> ", todoList);
    
			res.send(todoList);
	
});

app.delete("/deleteAll/id", async(_req,res)=>{

    let isDeleted = await todoDao.deleteEntity(id);
    console.log("Is it deleted --> ", isDeleted)
    res.send(isDeleted);
});

app.post("/insert", async(req,res)=>{

    let savedTodo = await todoDao.saveEntity({
        title: "Read a book of JS",
        completed: 0
});



app.listen(port, () => console.log(`Example app listening on port ${port}!`));
