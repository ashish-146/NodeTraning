const fs=require('fs')

const util =require('util')

let promise=new Promise(function(resolve,reject){
    fs.readFile('temp.txt','utf-8',function(err,content){
        if(err) return reject(err);
        return resolve(content);
    })
})

promise.then(function(content){
    console.log("then"+content)
})
.catch(function(err){
    console.log("some err"+err)
})
.finally(function(){
    console.log("then"+content)
})

let x=promise.then(function(content){
    console.log("then"+content)
    
})