// function op(a,b,operation){

// function add(a,b){
//     return a+b;
// }
// function sub(a,b){
//     return a-b;
// }
// }
// function calculator(a,b,op){
//     return op(a,b,op);
// }

// console.log(calculator(10,5,add));
// console.log("operation is perform");


for(var i=0;i<5;i++)
{
    setTimeout(()=>{

        console.log(i);
    })
}




(function run(){
    console.log("running");
})()


function add(a, b , callback){ 
    console.log(a+b); 
    callback(); 
    } 

    function disp(){ 
        console.log('This must be printed after addition'); 
        }

        add(5,6,disp);     
     