(function run(){
console.log('running')
})()

