var fs=require('fs');

function readDirectories(err,data){
    console.log('data',data);
}  //callback functions

// data=fs.readdirSync('D:/');
// console.log('data:',data);

fs.readdir('D:/',readDirectories);
console.log("this comes after.");

