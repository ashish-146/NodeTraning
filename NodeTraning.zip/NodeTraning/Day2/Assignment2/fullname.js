module.exports=function(){
    this.fullname=function(fname,lname){
        name=fname+" "+lname;
        return name;
    }
}