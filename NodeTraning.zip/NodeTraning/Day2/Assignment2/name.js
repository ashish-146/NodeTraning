var name=require("./fullname.js");
var newname=new name();
console.log(newname.fullname("Ashish","Patil"));