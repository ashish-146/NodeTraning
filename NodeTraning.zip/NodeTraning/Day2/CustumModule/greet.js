module.exports=function(){
    this.sayHello=function(){
        return "Hello from greet!!!"
    }
}