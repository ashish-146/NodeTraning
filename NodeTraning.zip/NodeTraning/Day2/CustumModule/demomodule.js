var http=require('http');

var myModule=require("./mymodule.js");//my module is custum module

console.log("My name is:"+myModule.name)
HTMLOutputElement.createServer(function(req,res){
    // console.log("My name is :"+myModule.name);
    res.writeHead(200,{'content-type':'text/html'});
    var name=myModule.name;
    res.end(name);
}).listen(8050);
