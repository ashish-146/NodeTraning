var hello=require("./greet.js");
var myModule=require("./mymodule.js");

console.log(myModule.name)
var newgreet=new hello();
console.log(newgreet.sayHello())