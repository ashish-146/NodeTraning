var myModule=require("./usemodule")
//console.log("My name is:" + myModule.name)var http=require('http');
var http=require('http');
var ejs = require('ejs');
var html='<html<head></head><body><p>My name is<%=name %></p></body></html>'
http.createServer(function(req,res){
	//res.end(" Rakshanda Raut")
	//res.send("hiiiii!!!!!!!")
	var name=myModule.name;
	
    res.writeHead(200,{'content-type':'text/html'});
    var name=myModule.name;
    res.end(name);
}).listen(8050);
