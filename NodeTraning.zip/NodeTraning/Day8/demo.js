var http = require('http');
var fs = require('fs');
let content = 'Welcome';
http.createServer(function(req,res){
    fs.readFile('demo.html',function(err,data){
        res.writeHead(200,{'Content-Type':'text/html'});
        console.log("Server Started on Port 9000....");
        res.write(data);
        res.end();
    }) 
    /*
    fs.writeFile('demo.txt', 'Hello Pooja!!!', function (err) {
        if (err) throw err;
        console.log('Saved!');
      });*/
      fs.writeFile('demo.txt',content,function(err){
        if (err) throw err;
        console.log('Content Saved!'); 
      })
}).listen(1111);