var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

// router.get('/auth', verifyUser,function(req, res, next) {
//   res.render('index', { title: 'Express' });
//   console.log("Ashish");
//   res.send("varified user");
// });

router.get('/auth' , function(req, res,next){
  res.send("Hello World");
  res.end();
  next();
},verifyUser);

function verifyUser(){
  console.log("verified user");
  
}


module.exports = router;

