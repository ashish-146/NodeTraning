import $ from "jquery";


$(document).ready(function(){
    $("#document").html("<h1>Hello Ashish</h1>");
});

$(document).ready(()=>{
    $("#document").html("<h1>Hello Ashish</h1>");
});