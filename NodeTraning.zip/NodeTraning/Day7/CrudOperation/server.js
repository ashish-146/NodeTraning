const express = require('express');
const path=require('path');
const app=express();
const port=5000;

app.use(express.static("dist"));

app.get("/",(_req,res)=>{
    res.sendFile(path.join(path.resolve("dist"),"index.html"));
});

app.listen(port,()=>console.log(`example app listing post ${port}!`));