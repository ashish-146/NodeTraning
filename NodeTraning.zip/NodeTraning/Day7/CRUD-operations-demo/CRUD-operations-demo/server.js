const express = require("express");
const path = require("path");
const app = express();
const bodyParser = require("body-parser");
const MongoClient = require("mongodb").MongoClient;
const url = "mongodb://127.0.0.1:27017/";
const port = 3000;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("dist"));

let dbo;

MongoClient.connect(
	url,
	{ useNewUrlParser: true, useUnifiedTopology: true },
	(err, db) => {
		if (err) throw err;
		dbo = db.db("emp_db");
	}
);

app.get("/", (_req, res) => {
	res.sendFile(path.join(path.resolve("dist"), "index.html"));
});

app.get("/getAllEmployees", (_req, res) => {
	dbo.collection("employees")
		.find()
		.toArray((err, result) => {
			if (err) throw err;
			res.send(result);
		});
});

app.listen(port, () => console.log(`Example app listening on port ${port}!`));
