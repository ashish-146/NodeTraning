import $ from "jquery";

$(document).ready(() => {
	$.ajax({
		url: "/getAllEmployees",
		method: "GET",
		data: {},
		success: data => {
			let rowData;
			data.forEach(item => {
				rowData += `<tr><td>${item.empId}</td><td>${item.firstName}</td><td>${item.lastName}</td><td>${item.email}</td><td>${item.phone}</td></tr>`;
			});
			$("#emp-table tbody").html(rowData);
		}
	});
});
