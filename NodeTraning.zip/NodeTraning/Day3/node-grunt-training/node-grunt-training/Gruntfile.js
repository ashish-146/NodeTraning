module.exports = function(grunt) {
	grunt.initConfig({
		uglify: {
			options: {
				mangle: false
			},
			dist: {
				files: {
					"dest/output.min.js": "js/script.js"
				}
			}
		}
	});
	grunt.loadNpmTasks("grunt-contrib-uglify");
	grunt.registerTask("default", ["uglify"]);
};
