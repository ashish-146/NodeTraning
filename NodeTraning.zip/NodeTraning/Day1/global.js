console.log("Hello World");
global.console.log("Ashish")

var hello="Hello From Node js";
console.log(hello)

var justnode=hello.slice(10)

console.log(justnode)

console.log(`Rock on ${justnode}`)

console.log(__dirname);
console.log(__filename)

var path=require("path")
console.log(`Rock on ${path.basename(__filename)}`)

//npm and package.json


var us=require("underscore");
var us=require("express");
console.log(`Rock on ${path.basename(__filename)}`)

//Express

console.log("Hello nodemon");

console.log("hey I'm using nodeomon");