var http=require("http"); //importing http and assign to variable http

http.createServer(function(req,res){
    res.write("Hello World")
    res.end()
}).listen(8088)