import $ from "jquery";

$(document).ready(() => {
	$.ajax({
		url: "/getAll",
		method: "GET",
		data: {},
		success: data => {
			let rowData;
			data.forEach(item => {
				rowData += `<tr><td>${item.id}</td><td>${item.title}</td><td>${item.completed}</td></tr>`;
			});
			$("#info-table tbody").html(rowData);
		}
	});
});
