const express = require("express");
const path = require("path");
const app = express();
const bodyParser = require("body-parser");

var mysql      = require('mysql');
// const mysql = require('promise-mysql');
const port = 5000;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("dist"));

let dbo;



var connection = mysql.createConnection({
    host     : 'localhost',
    user     : 'root',
    password : '',
    database : 'todo_dev'
  });
  connection.connect();
 
// connection.query('SELECT 1 + 1 AS solution', function (error, results, fields) {
//   if (error) throw error;
//   console.log('The solution is: ', results[0].solution);
//   dbo = result.db("todo_dev");
// });
 
// connection.end()

// mysql.connect(
// 	url,
// 	{ useNewUrlParser: true, useUnifiedTopology: true },
// 	(err, db) => {
// 		if (err) throw err;
// 		dbo = db.db("todo_dev");
// 	}
// );

connection.connect(function(err,db) {
    if (err) {
      console.error('error connecting: ' + err.stack);
      return;
    }
   
    console.log('connected as id ' + connection.threadId);

    dbo = db.db("todo_dev");

  });
   

app.get("/", (_req, res) => {
	res.sendFile(path.join(path.resolve("dist"), "index.html"));
});

app.get("/getAll", (_req, res) => {
    // dbo.collection("employees")
    dbo.collection("tbl_todo")
		.find()
		.toArray((err, result) => {
			if (err) throw err;
			res.send(result);
		});
});

app.listen(port, () => console.log(`Example app listening on port ${port}!`));
